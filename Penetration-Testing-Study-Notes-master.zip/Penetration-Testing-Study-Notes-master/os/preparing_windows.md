# Windows machine setup

I’ll install the following:

1. HxD http://mh-nexus.de/en/hxd/

2. Evade https://www.securepla.net/antivirus-now-you-see-me-now-you-dont/

3. Hyperion http://www.nullsecurity.net/tools/binary.html

    - Download/install a Windows Compiler http://sourceforge.net/projects/mingw/
    - Run “make” in the extracted Hyperion folder and you should have the binary.

4. Download and install Metasploit http://www.Metasploit.com/

5. Download and install either Nessus or Nexpose

    - If you are buying your own software, you should probably look into Nessus as it is much cheaper, but both work well

6. Download and install nmap http://nmap.org/download.html

7. Download and install oclHashcat http://hashcat.net/oclhashcat/#downloadlatest

8. Download and install evil foca http://www.informatica64.com/evilfoca/

9. Download and install Cain and Abel http://www.oxid.it/cain.html

10. BURP http://portswigger.net/burp/download.html

11. Download and extract Nishang: https://code.google.com/p/nishang/downloads/list

12. Download and extract PowerSploit: https://github.com/mattifestation/PowerSploit/archive/master.zip

13. Installing Firefox Addons

    - Web Developer Add-on: https://addons.mozilla.org/en-US/firefox/addon/web-developer/
    - Tamper Data: https://addons.mozilla.org/en-US/firefox/addon/tamper-data/
    - Foxy Proxy: https://addons.mozilla.org/en-US/firefox/addon/foxyproxy-standard/
    - User Agent Switcher: https://addons.mozilla.org/en-US/firefox/addon/user-agentswitcher/
