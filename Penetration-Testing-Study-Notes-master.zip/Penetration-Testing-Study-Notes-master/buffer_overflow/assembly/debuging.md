# Debuging using GDB

## Compiling C code with GDB debug symbols

```Shell
>> gcc -ggdb <file_name.c> -o <output_file_name>
```
