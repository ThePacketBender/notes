# NFS_Enumeration (Network File System).html

- Show Mountable NFS Shares

```ShellSession
nmap -sV --script=nfs-showmount $ip
```

