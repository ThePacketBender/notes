# MS SQL Server Enumeration

- Nmap Information Gathering

```ShellSession
nmap -p 1433 --script ms-sql-info,ms-sql-empty-password,ms-sql-xp-cmdshell,ms-sql-config,ms-sql-ntlm-info,ms-sql-tables,ms-sql-hasdbaccess,ms-sql-dac,ms-sql-dump-hashes    --script-args mssql.instance port=1433,mssql.username=sa,mssql.password=,mssql.instance-name=MSSQLSERVER $ip
```
