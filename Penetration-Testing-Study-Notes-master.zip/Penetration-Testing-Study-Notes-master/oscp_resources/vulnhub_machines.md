# Vulnhub machines similar to OSCP lap

If you’re not familiar with  vulnhub.com, check it out. They have a ton of Boot2Root/CTF style vms and some of them are similar to lab machines. Below is a list of vms that were similar to lab machines that I completed while studying for the OSCP:

- Kioptrix Level 1
- Kioptrix Level 1.1
- Kioptrix Level 1.2
- Kioptrix2014
- pWnOS v2.0
- SickOs 1
- SickOS 1.2
- Stapler
- Tr0ll
- Tr0ll2
- Vulnix
- VulnOSv2
- FristiLeaks 1.3
- LordOfTheRoot 1.0.1
- mrRobot
- pwnlab_init

I don’t think I would have been successful in passing the exam if I did not complete these Vulnhub vms. I would HIGHLY recommend you complete all of these before taking the exam. DO NOT complete these vms without understanding every single step you take to root them and remember, document, document, and then document some more :).
